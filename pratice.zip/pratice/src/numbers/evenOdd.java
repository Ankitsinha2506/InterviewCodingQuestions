package numbers;

public class evenOdd {
    public static void main(String [] args){
        int i = 6;
        if (i % 2 == 0){
          System.out.println("Number is Even");
        }
        else {
            System.out.println("Number is odd");
        }
    }
}
