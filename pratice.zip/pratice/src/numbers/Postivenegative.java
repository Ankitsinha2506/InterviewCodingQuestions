package numbers;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Postivenegative {
    public static void main(String[] args) {
        int i = -1;

//        if(i > 0){
//            System.out.println("Number is positive");
//        } else if (i < 0) {
//            System.out.println("Number is neagative");
//        }
//        else{
//            System.out.println("Number is zero");
    //}

        if (i >= 0) {
            if (i == 0){
                System.out.println("Number is zero");
            }
            else {
                System.out.println("Number is positive");
            }
        }
        else {
            System.out.println("Number is neagtive");
        }
    }
}