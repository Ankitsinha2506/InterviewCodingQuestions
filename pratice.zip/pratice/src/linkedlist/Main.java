package linkedlist;

public class Main {

    public static void main(String[] args) {
//        Linkedlist ll = new Linkedlist();
//        ll.insertFirst(3);
//        ll.insertFirst(5);
//        ll.insertFirst(7);
//        ll.insertFirst(8);
//        ll.insertLast(99);
//        ll.insert(25,4);
//        System.out.println(ll.deleteFirst());
//        System.out.println(ll.deleteLast());
//        System.out.println(ll.delete(2));
//        ll.display();

        DoublyLinkedList dll = new DoublyLinkedList();
        dll.insertFirst(10);
        dll.insertFirst(20);
        dll.insertFirst(30);
        dll.insertFirst(40);
        dll.insertFirst(50);
        dll.insertLast(5);
        dll.display();
    }
}
