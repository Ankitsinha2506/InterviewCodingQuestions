package praticeown;

public class RandomNumber {
    public static void main(String[] args){
        double n = Math.random();
        System.out.println(n);
    }
}
